# devssl

These files are for development and CI purposes only.
They are not for use in production.

https://gist.github.com/mrw34/c97bb03ea1054afb551886ffc8b63c3b is where I got the script to generate these.

Note that the file `server.key` must be owned by uid 70.  This is done via sudo in the dev setup script.